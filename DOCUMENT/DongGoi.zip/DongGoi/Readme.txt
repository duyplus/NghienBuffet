﻿Thực hiện theo các bước sau đây để cài đặt
1. Cài JDK 1.8+ (nếu chưa cài)
2. Cài SQL Server 2008+ (nếu chưa cài)
3. Chạy Nghien_Buffet.sql để tạo CSDL Nghien_Buffet và đặt mật khẩu của tài khoản sa của SQL Server là 123456
4. Chạy NghienBuffet-Setup.exe để cài ứng dụng NghienBuffet
5. Chạy và đăng nhập với tài khoản
- Quản lý:
+ username: admin
+ password: 123456
- Nhân viên:
+ username: staff
+ password: 123456